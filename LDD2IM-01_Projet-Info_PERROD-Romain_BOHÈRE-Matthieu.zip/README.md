# Binôme
- PERROD Romain
- BOHÈRE Matthieu

# Exécution du code

Pour exécuter les fichiers tests, faire `./tests.sh` dans un Terminal : tout sera exécuté petit à petit.